# -*- coding: utf-8 -*-
"""
SPR Sensor Analyst - 源代码包
"""
__version__ = "2.0.0-mvp"

